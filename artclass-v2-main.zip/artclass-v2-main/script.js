function back() {
  window.location.back();
}

function reload() {
  
}